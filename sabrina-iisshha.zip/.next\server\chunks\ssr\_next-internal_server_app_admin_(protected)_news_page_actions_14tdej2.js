module.exports=[6398,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28protected%29_news_page_actions_14tdej2.js.map