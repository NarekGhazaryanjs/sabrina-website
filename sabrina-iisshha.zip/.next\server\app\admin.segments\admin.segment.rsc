1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
3:I[37457,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[null,["$","div",null,{"lang":"ru","className":"min-h-screen bg-plum text-pearl","children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"ONyVFYRAblOL7k2s_ui_1"}
