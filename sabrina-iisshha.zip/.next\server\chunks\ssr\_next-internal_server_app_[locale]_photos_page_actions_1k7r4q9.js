module.exports=[51586,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_photos_page_actions_1k7r4q9.js.map