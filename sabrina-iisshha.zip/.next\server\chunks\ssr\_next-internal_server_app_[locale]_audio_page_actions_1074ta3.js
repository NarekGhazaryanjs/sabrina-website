module.exports=[16670,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_audio_page_actions_1074ta3.js.map