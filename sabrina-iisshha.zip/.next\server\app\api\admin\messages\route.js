var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/messages/route.js")
R.c("server/chunks/[root-of-the-server]__1pq_nch._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_1dk16sf._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_messages_route_actions_1zie6py.js")
R.m(61173)
module.exports=R.m(61173).exports
