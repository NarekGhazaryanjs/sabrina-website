globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ONyVFYRAblOL7k2s_ui_1/_buildManifest.js",
    "static/ONyVFYRAblOL7k2s_ui_1/_ssgManifest.js",
    "static/ONyVFYRAblOL7k2s_ui_1/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yiddnbtmgj46.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/43_bvheqq33cs.js",
    "static/chunks/0xzd24dhqjey5.js",
    "static/chunks/turbopack-2nij_27-2cgvn.js"
  ]
};
