var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/media/route.js")
R.c("server/chunks/[root-of-the-server]__1uggt3z._.js")
R.c("server/chunks/_1dk16sf._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0pyfcyy._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_media_route_actions_0vxfg-a.js")
R.m(78685)
module.exports=R.m(78685).exports
