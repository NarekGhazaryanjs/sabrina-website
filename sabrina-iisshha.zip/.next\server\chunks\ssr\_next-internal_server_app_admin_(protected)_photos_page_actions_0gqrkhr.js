module.exports=[2863,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28protected%29_photos_page_actions_0gqrkhr.js.map