1:"$Sreact.fragment"
2:I[22016,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/2-at_ecf5u5ap.js","/_next/static/chunks/2het60zsgn4ry.js"],""]
3:I[60079,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/2-at_ecf5u5ap.js"],"LogoutButton"]
4:I[39756,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
5:I[37457,["/_next/static/chunks/05-c3ty_6dwfk.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/2-at_ecf5u5ap.js","async":true}]],[["$","header",null,{"className":"border-b border-rose-400/8 bg-plum-light/50","children":["$","div",null,{"className":"mx-auto flex max-w-5xl items-center justify-between px-6 py-4","children":[["$","$L2",null,{"href":"/admin","className":"font-display text-lg gradient-text","children":"Sabrina Admin"}],["$","$L3",null,{}]]}]}],["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"ONyVFYRAblOL7k2s_ui_1"}
