var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/pages/route.js")
R.c("server/chunks/[root-of-the-server]__0dzx315._.js")
R.c("server/chunks/_1dk16sf._.js")
R.c("server/chunks/_0pyfcyy._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_pages_route_actions_0_pd6-i.js")
R.m(52407)
module.exports=R.m(52407).exports
