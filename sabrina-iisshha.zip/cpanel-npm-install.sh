#!/bin/bash
set -e
cd "$(dirname "$0")"
npm install --omit=dev --no-audit --no-fund --legacy-peer-deps
echo "Done. Edit .env then Restart app in cPanel."
