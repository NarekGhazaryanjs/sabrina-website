var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/news/route.js")
R.c("server/chunks/[root-of-the-server]__1ngrvdv._.js")
R.c("server/chunks/_1dk16sf._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0pyfcyy._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_news_route_actions_1gbf62h.js")
R.m(34725)
module.exports=R.m(34725).exports
