var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/route.js")
R.c("server/chunks/[root-of-the-server]__1-s6v5k._.js")
R.c("server/chunks/_1dk16sf._.js")
R.c("server/chunks/_0pyfcyy._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_settings_route_actions_20mpcqu.js")
R.m(11094)
module.exports=R.m(11094).exports
