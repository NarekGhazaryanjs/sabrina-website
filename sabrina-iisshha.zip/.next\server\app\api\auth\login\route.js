var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__0j48li7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_1dk16sf._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_1ox7zi0.js")
R.m(30450)
module.exports=R.m(30450).exports
