const fs = require("fs");
const path = require("path");

function loadEnvFile() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, "utf8").split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim();
    if (!process.env[key]) process.env[key] = value;
  }
}

function ensureWritableDirs() {
  for (const dir of [
    "data",
    "public/uploads/videos",
    "public/uploads/photos",
    "public/uploads/audio",
    "public/uploads/news",
  ]) {
    fs.mkdirSync(path.join(__dirname, dir), { recursive: true });
  }
}

function patchLinuxPaths(config) {
  if (config.outputFileTracingRoot) config.outputFileTracingRoot = ".";
  if (config.turbopack?.root) config.turbopack.root = ".";
  return config;
}

loadEnvFile();
ensureWritableDirs();

if (!process.env.AUTH_SECRET) {
  console.error("AUTH_SECRET is missing. Add it in cPanel env vars or .env file.");
}

if (!process.env.HOSTNAME) {
  process.env.HOSTNAME = "127.0.0.1";
}

try {
  require("./app-server.js");
} catch (error) {
  const message = error instanceof Error ? error.stack || error.message : String(error);
  fs.writeFileSync(path.join(__dirname, "startup-error.log"), message);
  console.error(message);
  process.exit(1);
}
