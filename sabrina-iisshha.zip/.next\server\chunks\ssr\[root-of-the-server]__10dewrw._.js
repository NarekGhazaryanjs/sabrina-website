module.exports=[63387,a=>{a.v({className:"playfair_display_9684ff4f-module__ERjKUG__className",variable:"playfair_display_9684ff4f-module__ERjKUG__variable"})},79083,a=>{a.v({className:"nunito_8e8a53f6-module__xoBPHW__className",variable:"nunito_8e8a53f6-module__xoBPHW__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(63387);let d={className:c.default.className,style:{fontFamily:"'Playfair Display', 'Playfair Display Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(79083);let f={className:e.default.className,style:{fontFamily:"'Nunito', 'Nunito Fallback'",fontStyle:"normal"}};function g(){let a=`
(function () {
  try {
    var key = "sabrina-theme";
    var stored = localStorage.getItem(key);
    var theme =
      stored === "light" || stored === "dark"
        ? stored
        : window.matchMedia("(prefers-color-scheme: light)").matches
          ? "light"
          : "dark";
    document.documentElement.setAttribute("data-theme", theme);
  } catch (e) {
    document.documentElement.setAttribute("data-theme", "dark");
  }
})();
`;return(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:a},suppressHydrationWarning:!0})}null!=e.default.variable&&(f.variable=e.default.variable);let h={title:{default:"Sabrina",template:"%s | Sabrina"},description:"Sabrina — official website. Streams, videos, photos, news and more.",metadataBase:process.env.SITE_URL?new URL(process.env.SITE_URL):void 0,openGraph:{title:"Sabrina",description:"Sabrina — official website",type:"website",locale:"en_US",alternateLocale:["ru_RU"]},robots:{index:!0,follow:!0}};a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en","data-theme":"dark",suppressHydrationWarning:!0,className:`${d.variable} ${f.variable}`,children:[(0,b.jsx)("head",{children:(0,b.jsx)(g,{})}),(0,b.jsx)("body",{className:"gradient-bg min-h-screen antialiased",children:a})]})},"metadata",0,h,"viewport",0,{width:"device-width",initialScale:1,maximumScale:5}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__10dewrw._.js.map