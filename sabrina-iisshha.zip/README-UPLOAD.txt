Sabrina — cPanel upload (Linux-compatible)
==========================================

1. Upload ALL files to iisshha-site (NOT node_modules)
2. Edit .env — set AUTH_SECRET and ADMIN_PASSWORD
3. Node.js App → startup file: server.js
4. Run NPM Install (or: bash cpanel-npm-install.sh)
5. Restart app
6. If error: read startup-error.log in this folder

Prefer Linux-built zip from GitHub Actions artifact (sabrina-cpanel-linux).
