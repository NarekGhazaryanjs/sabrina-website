module.exports=[73351,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_donate_page_actions_1hww7vm.js.map